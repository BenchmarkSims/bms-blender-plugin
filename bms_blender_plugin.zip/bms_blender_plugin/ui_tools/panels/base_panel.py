

class BasePanel:
    """Base class for the Panel - groups all subpanels"""
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Falcon BMS"
    bl_label = "Falcon BMS"
